package com.example.rentalapp;

public class Car {
    private String plateNo;
    private String Make;
    private String type;
    private double rate;
    private double extraCharge;
    private int millage;
    private int[] options = new int[4];

    public Car(String plateNo, String make, String type, double rate, double extraCharge, int millage, int[] options) {
        this.plateNo = plateNo;
        Make = make;
        this.type = type;
        this.rate = rate;
        this.extraCharge = extraCharge;
        this.millage = millage;
        this.options = options;
    }

    public String getPlateNo() {
        return plateNo;
    }

    public void setPlateNo(String plateNo) {
        this.plateNo = plateNo;
    }

    public String getMake() {
        return Make;
    }

    public void setMake(String make) {
        Make = make;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public double getExtraCharge() {
        return extraCharge;
    }

    public void setExtraCharge(double extraCharge) {
        this.extraCharge = extraCharge;
    }

    public int getMillage() {
        return millage;
    }

    public void setMillage(int millage) {
        this.millage = millage;
    }

    public int[] getOptions() {
        return options;
    }

    public void setOptions(int[] options) {
        this.options = options;
    }
}
