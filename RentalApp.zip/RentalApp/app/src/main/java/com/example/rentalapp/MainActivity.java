package com.example.rentalapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    String carMake[] = {"Nissan","Ford","Toyota","Honda"};
    //list of all cars with all details
    ArrayList<Car> cars = new ArrayList<Car>();
    //list of cars types which belong to the selected car make so it keeps changing
    ArrayList<String>selectdMake = new ArrayList<String>();
    Spinner makeSp,typeSp;
    CheckBox chbx[] = new CheckBox[4];
    ImageView carImg;

    //method to fill the car details in the list
    public void setCarsDetails(){


        cars.add(new Car("ABC 234","Ford","Escape",40,0.7,3450,new int[]{0,1,1,0}));
        cars.add(new Car("XYR 837","Nissan","Rogue",45,0.75,2560,new int[]{1,1,0,0}));
        cars.add(new Car("ABC 234","Ford","Edge",50,0.7,1234,new int[]{0,0,1}));
        cars.add(new Car("RLB 456","Nissan","Sunny",30,0.5,3450,new int[]{1,0,0,0}));
        cars.add(new Car("ASD 634","Toyota","Corolla",37,0.6,5678,new int[]{0,0,0,0}));
        cars.add(new Car("BBC 334","Ford","Focus",37,0.7,3450,new int[]{1,0,0,0}));
        cars.add(new Car("YTR 834","Nissan","Tida",35,0.75,2560,new int[]{1,0,0,0}));
        cars.add(new Car("BGH 267","Ford","Explorer",57,0.7,1234,new int[]{1,1,1,1}));
        cars.add(new Car("MKL 412","Nissan","Altima",50,0.5,3450,new int[]{1,0,0,0}));
        cars.add(new Car("XHL 644","Toyota","Camry",49,0.6,5678,new int[]{1,1,0,0}));
        cars.add(new Car("AER 874","Honda","Civic",40,0.5,5678,new int[]{1,0,0,0}));
        cars.add(new Car("CAH 744","Honda","Accord",60,0.8,5678,new int[]{1,1,1,0}));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setCarsDetails();
        makeSp=findViewById(R.id.SpMake);
        typeSp=findViewById(R.id.spType);
        chbx[0]=findViewById(R.id.cb1);
        chbx[1]=findViewById(R.id.cb2);
        chbx[2]=findViewById(R.id.cb3);
        chbx[3]=findViewById(R.id.cb4);
        carImg=findViewById(R.id.imageView);

        makeSp.setOnItemSelectedListener(this);
        typeSp.setOnItemSelectedListener(this);

        //fill the make spinner of car makes from the carmake array
        ArrayAdapter makeAdap = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,carMake);
        makeAdap.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        makeSp.setAdapter(makeAdap);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if(adapterView.getId()==R.id.SpMake){
            //empty the list of car types which is filled upon the selected make
            selectdMake.clear();
            //browsing the list of all cars details
            for(int j=0;j<cars.size();j++){
                //find any car that belongs to the selected car make
                if(cars.get(j).getMake().equals(carMake[i]))
                    //add the car type to the short list of the selected car make
                    selectdMake.add(cars.get(j).getType());
            }

            ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,selectdMake);
            aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            typeSp.setAdapter(aa);


        }
        else if(adapterView.getId()==R.id.spType){
            int index=searchCars(selectdMake.get(i));
            chkBoxes(index);
            String imgName = cars.get(index).getType().toLowerCase();
            int imgId=getResources().getIdentifier(imgName,"drawable",getPackageName());
            carImg.setImageResource(imgId);




        }
    }

    public void chkBoxes(int index){
        int i = index;
        for(int j=0;j<4;j++)
            //go to the selected car in the original list of all cars details and get the options
            //then check each option if its 1 check the check box of the same option index
            if(cars.get(i).getOptions()[j]==1)
                chbx[j].setChecked(true);
            else
                chbx[j].setChecked(false);



    }
    //a method to find the index of the car in the original car list by its type
    public int searchCars(String carType){
        for(int i=0;i<cars.size();i++)
            if(cars.get(i).getType().equals(carType))
                return i;
        return -1;
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
